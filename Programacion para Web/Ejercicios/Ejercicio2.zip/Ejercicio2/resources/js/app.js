const app = {
    urlPosts: 'https://jsonplaceholder.typicode.com/posts',
    urlComments: 'https://jsonplaceholder.typicode.com/comments',
    urlUsers: 'https://jsonplaceholder.typicode.com/users',

    loadPosts : function() {
        // const cont = document.querySelector('#content');
        const cont = $("#content");
        cont.css("width", "100%");
        cont.addClass("mx-auto mt-5");
        let html = ""
    }
}