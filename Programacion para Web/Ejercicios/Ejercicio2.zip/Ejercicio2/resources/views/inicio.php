<?php
include "layouts/main_header.php";
include "layouts/main_footer.php";

head();
    ?>
<div class="row mx-auto mt-5" style="width: 90%">
    <div class="col-8 shadow p-3 mb-5 bg-body-tertiary rounded">
        <div class="content" id="content">

        </div>
    </div>
    <div class="col-4 shadow p-3 mb-5 bg-body-tertiary rounded">
        <div class="autores list-group" id="autores">

        </div>
    </div>
</div>
</div>
<?php
foot();
?>
