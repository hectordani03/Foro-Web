<?php
function foot(...$args)
{
?>
<script src="../../resources/js/jquery.min.js"></script>
<script src="../../resources/js/bootstrap.min.js"></script>
</body>
</html>
<?php
}
?>